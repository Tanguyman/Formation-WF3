# IONIC SLACK UI -  v0.0.3

Ionic Slack user interface theme!

<img src="https://s3.amazonaws.com/ionic-marketplace/ionic-slack-ui-theme-free/screenshot_4.gif" width="200">
<img src="https://s3.amazonaws.com/ionic-marketplace/ionic-slack-ui-theme-free/screenshot_1.jpeg" width="200">
<img src="https://s3.amazonaws.com/ionic-marketplace/ionic-slack-ui-theme-free/screenshot_2.jpeg" width="200">

## Cordova plugins
* ionic-plugin-keyboard
* cordova-plugin-statusbar
* cordova-plugin-splashscreen


## SASS
* Easily modify styles `www/lib/slackUI/scss/*`
* run  `ionic setup sass`
* run `ionic serve`


## Download
https://github.com/luisbahamonde/ionic-slack
